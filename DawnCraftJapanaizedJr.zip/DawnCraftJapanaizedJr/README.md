## はじめに
当該ファイルはDawnCraft製作者陣並びに、翻訳MOD製作者：【ハリイロ】様とは関係の無いものです。  
**この翻訳ファイル等についてDawnCraft製作者やDiscordコミュニティ、ハリイロ様へ問い合わせを行うのはお控えください。**  
このファイルはハリイロ様のDawnCraftクエスト翻訳ファイル【global_packs】をもとにDawnCraft2.0に対応させたものです。
追加翻訳した部分は機械翻訳のため違和感があるかもしれません。
エラー確認したのはワールドの生成までであり、それ以後のエラーは保証できません。ご了承ください。

導入方法並びにほかの翻訳ファイルはハリイロ様の DawnCraftJapanaizedを参照してください。
https://github.com/haricolor/DawnCraftJapanaized
